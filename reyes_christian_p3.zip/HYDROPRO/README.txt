This is every HydroPRO dock icon I have ever made. This pack includes some unreleased ones which I was never happy with, but you guys might.

Remember, every single icon is free for use in any way; this includes commercially!

Finally, http://mediadesign.deviantart.com is my homepage. Feel free to visit any time and check out my wide range of work if you've gotten tired of my icons.